const jwt = require('jsonwebtoken');
const User = require('../models/userSchema');

const auth = async (req, res, next) => {
    try {
        //const token = req.header('Authorization').replace('Bearer ', '')
        let token = req.session.token;
        console.log(token);
        token = String(token)
        let decoded = jwt.verify(token, "avm");
        //const user = await User.findOne({ _id: decoded._id, 'tokens.token': token })

        /*const user = await {name:verified.name};  
        /*if (!user) {
            throw new Error()
        }

        req.token = token
        req.user = user*/
        //console.log(user);
        console.log(decoded);
        next()
    } catch (e) {
        console.log(e);
        res.status(401).send({ error: 'Please authenticate.' })
    }
}

module.exports = {auth};