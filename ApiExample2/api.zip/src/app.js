const express = require("express");
const app = express();
const Order = require("./models/schema");
require("./db/conn");
const route = require("./routes/routes");
const ui = require("./routes/frontEndRoute");
const session = require('express-session');

app.use(express.json())

app.use(session({
secret : 'avm',
resave : false,
saveUninitialized : false,
 cookie: {
 
            //1 min 
            expires: 60000
        }
}));


const bodyParser = require("body-parser");
const port = process.env.PORT || 8000;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view engine','ejs');
app.use("/productOrder",route);
app.use("/forms",ui);




app.listen(8000,() => {

	console.log("server is running");
});
///home/ajay/Desktop/Mern/ApiExample2/views"