const express = require("express");
const userData = require("../models/userSchema");
const bcrypt = require('bcryptjs');
const { json } = require("express");
const jwt = require("jsonwebtoken");

const userController = {};

userController.signUp = async (req, res) => {
        
     bcrypt.hash(req.body.password, 8, (err, hash) => {
         if (err) {
             return res.status(500).send("Error");
         }
         else {
            const user = new userData({
                 name: req.body.name,
                email: req.body.email,
                password: hash,
                 confirmPassword: hash
             })
             if (req.body.password == req.body.confirmPassword) {
                 const result = user.save().then((result, err) => {
                 	console.log(result);
                     res.render("signin");
                 })
             }
             else {
                 res.send("password is not matching")
             }

       }
     })
}

userController.signIn = async (req, res) => {
    var result = await userData.find({ name: req.body.name })
    if (result.length < 1) {
        return res.status(401).json({
            msg: "user not exist"
        })
    }
    bcrypt.compare(req.body.password, result[0].password,async (err, result2) => {
        if (!result2) {
            return res.status(401).json({
                msg: "password matching is fail"
            })
        }

        if (result2) {
            const token =await jwt.sign({
                name: result[0].name,
                password: result[0].password
            }, 'avm', {
                expiresIn: "24h"
            })
            console.log(token);

            /*res.status(200).json({
                name: result[0].name,
                token: token,
                msg:"LoggedIn successfully"

            })*/
            req.session.token = token;
            console.log(req.session);
            return res.status(201).render("crud")
        }
    })

};

module.exports = {userController};
