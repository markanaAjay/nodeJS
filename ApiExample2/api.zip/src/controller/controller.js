const express = require("express");
const Order = require("../models/schema");
const userData = require("../models/userSchema");
const bcrypt = require('bcryptjs');
const { json } = require("express");
const jwt = require("jsonwebtoken")

const controller = {};
const userController = {};


controller.post =async (req,res)=>{
        
	console.log(req.body);
	const user = await new Order(req.body);
	
	user.save().then(() =>{
		res.status(201).render("home");
	}).catch((error) =>{
		res.status(400).send(error);
		console.log(error)
	})
}

controller.get = async(req,res)=>{
	try{
		const order = await Order.find({});
		res.send(order);
	}
	catch(error) {
		res.status(400).send(error);
	}
    //console.log("get");   
    //res.render("index");
    // return res.json(req.body);
}

controller.patch = async(req,res)=>{
	try{

        console.log(req.query);
        /*const order = await Order.find({});
        console.log(order);*/

        const data = Order.findOneAndUpdate({OrderId: req.query.OrderId}, {$set:{Name:req.query.Name}},function(err, doc){
        if(err){
        console.log("Something wrong when updating data!");
        }

        console.log(data);
        });

        
		res.send("success");
	}
	catch(error) {
        console.log(error);
		res.status(500).send(error);
	}
}

controller.delete = async(req,res)=>{
	try{
        /*const order = await Order.deleteOne({
            $match: req.query
        })*/
        const data = Order.findOneAndDelete({Name: req.query.Name }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Deleted User : ");
        }
        });
        console.log(data);
        
       
        return res.send("success");
	}
	catch(error) {
        console.log(error);
		res.status(500).send(error);
	}
}


module.exports = {controller};
