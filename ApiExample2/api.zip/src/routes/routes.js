const express = require("express");
const router = express.Router();
const Order = require("../models/schema");
const {controller} = require("../controller/controller");
const {userController} = require("../controller/auth");
const {auth} = require("../middleware/authMiddleware");


router.get("/",controller.get);
router.post("/",auth,controller.post);



router.get("/update",auth,controller.patch);

router.get("/delete",auth,controller.delete);

router.post("/SignIn", userController.signIn);

router.post("/SignUp",userController.signUp);

module.exports = router;

/*
{
    "OrderId" : "CCADF",
	"OrderAmount": 20,
	"Name":"XYZ",
	"Address":"rajkot",
	"City":"Rajkot",
	"State":"Gujrat",
	"ZipCode":360003,
	"PhoneNumber":9786411019,
	"Email":"avm@gmail.com",
	"TrackingNumber":3985563
	
}
*/