const express = require("express");
const router = express.Router();


router.get("/register",(req,res) =>{
	res.render("index");
});

router.get("/login",(req,res) =>{
	res.render("signin");
})

router.get("/home",(req,res) =>{
	res.render("crud");
})

router.get('/getSessionInfos', function(req,res,next){
    console.log(req.session);
});



module.exports = router;
