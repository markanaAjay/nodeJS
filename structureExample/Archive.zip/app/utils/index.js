const MongoDB = require("./lib/connection");


module.exports = {MongoDB};